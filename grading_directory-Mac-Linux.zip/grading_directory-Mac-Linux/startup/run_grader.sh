#!/bin/bash

# Docker command to run the grader
docker run --rm -v "$(pwd)":/grading_dir -w /grading_dir -v "$(pwd)"/tests/testcases:/grading_dir/tests/testcases -v "$(pwd)"/tests/extra:/grading_dir/tests/extra -v "$(pwd)"/tests/input:/grading_dir/tests/input -v "$(pwd)"/tests/output:/grading_dir/tests/output jmart5/containerized_autograding  /bin/bash -c "autograder run && cd / && python3 ./csv_generator.py"

